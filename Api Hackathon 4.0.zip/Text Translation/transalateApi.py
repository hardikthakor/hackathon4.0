import argparse
from google.cloud import translate
import six
from flask import Flask, request, jsonify, render_template
import json

app = Flask(__name__)

def translate_text(target, text):

    translate_client = translate.Client()

    if isinstance(text, six.binary_type):
        text = text.decode('utf-8')

    # Text can also be a sequence of strings, in which case this method
    # will return a sequence of results for each text.
    result = translate_client.translate(
        text, target_language=target)
    translated = u'{}'.format(result['translatedText'])
    """
    print(u'Text: {}'.format(result['input']))
    print(u'Translation: {}'.format(result['translatedText']))
    print(u'Detected source language: {}'.format(
        result['detectedSourceLanguage']))
    """
    return translated

@app.route('/translateApp',methods = ['POST', 'GET'])
def translateApp():
    print('okkkkkk')
    if request.method == 'POST':
        val = {}
        j = request.json
        lang = j['language']
        txt = j['text']
        val = translate_text(lang,txt)
        
        
        
        j = json.dumps({"text" : val})
        
        
        return j
    else:
        return "Post Your Request"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8010)





