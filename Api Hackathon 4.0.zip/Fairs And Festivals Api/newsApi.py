from flask import Flask, request, jsonify, render_template
import requests
import json
import urllib.request  as urllib2 
from bs4 import BeautifulSoup

app = Flask(__name__)




@app.route('/news',methods = ['POST', 'GET'])
def news():
    print('okkkkkk')
    if request.method == 'GET':
                quote_page = "http://tourism.rajasthan.gov.in/fairs-and-festivals.html"
                page = urllib2.urlopen(quote_page)

                soup = BeautifulSoup(page, 'html.parser')
                name_box = soup.find_all('h3')
                llist =[]
                dlist = []
                for i in name_box:
                    
                    name = i.text.strip() # strip() is used to remove starting and trailing
                    desc= i.next_sibling.next_sibling.text.strip()
                    llist.append(name)
                    dlist.append(desc)
                d = {"name":llist}
                d["desc"] = dlist



                img = soup.find_all('span' , attrs={'class':'sort-month'})
                ulist = []
                final = []
                for i in img:
                    data = str(i.previous.previous_sibling)
                    url = "http://tourism.rajasthan.gov.in"+eval(data.split("=")[3].split("src")[0])
                    ulist.append(url)
                    print(i)
                d["url"] = ulist
                print(d["url"])



                date = soup.find_all('div' , attrs={'class':'panel bgTwo'})


                srcDate= []
                desDate= []
                count = 0
                lcount = 0
                for i in date:
                    count = count + 1
                    lcount = lcount + 1
                    dates = i.p
                    month = i.p.next_sibling
                    for iter in month:
                        if lcount%2 and lcount<=40:
                            mon = iter
                        dats= str(dates).split(">")[1].split("<")[0]
                        if count%2 == 0:
				
                            desDate.append(dats+" "+mon)
                        else:
                            srcDate.append(dats+" "+mon)
				
                d["srcDate"] = srcDate
                d["desDate"] = desDate
                print("hogya")
                pk = json.dumps(d)
                
                return pk
    else:
        return "Post Your Request"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8016)


