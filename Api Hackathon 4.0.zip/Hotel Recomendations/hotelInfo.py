from flask import Flask, request, jsonify, render_template
import json
import requests
import urllib
import pandas as pd
app = Flask(__name__)


df = pd.read_csv('booking_com-travel_sample.csv') 

@app.route('/hotelInfo',methods = ['POST','GET'])
def hotelInfo():
    print("okkk")
    if request.method == 'POST':
        w = request.json
        a = df[df['city'] == str(w['city']).lower()][['property_name','site_review_rating','latitude','longitude','pageurl','hotel_description']] 
        c = a.dropna()
        b = c.head(10)
        hlist = []
        for i in range (0,10):
            data = {}
            data["hname"]=b['property_name'].iloc[i]
            data["hrating"] = b['site_review_rating'].iloc[i]
            data["hlat"] = b['latitude'].iloc[i]
            data["hlong"] = b['longitude'].iloc[i]
            data["hurl"] = b['pageurl'].iloc[i]
            data["desc"] = b['hotel_description'].iloc[i]
            hlist.append(data)
        j = json.dumps(hlist)
        return j
    
if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8014)
