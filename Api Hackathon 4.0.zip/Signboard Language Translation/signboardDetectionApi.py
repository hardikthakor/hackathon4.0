from flask import Flask, request, jsonify, render_template
import six
import io
from google.cloud import translate
import requests
import json
app = Flask(__name__)





def translate_text(target, text):

    translate_client = translate.Client()

    if isinstance(text, six.binary_type):
        text = text.decode('utf-8')

    # Text can also be a sequence of strings, in which case this method
    # will return a sequence of results for each text.
    result = translate_client.translate(
        text, target_language=target)
    translated = u'{}'.format(result['translatedText'])
    """
    print(u'Text: {}'.format(result['input']))
    print(u'Translation: {}'.format(result['translatedText']))
    print(u'Detected source language: {}'.format(
        result['detectedSourceLanguage']))
    """
    return translated




@app.route('/sign',methods = ['POST', 'GET'])
def sign():
    print('okkkkkks')
    if request.method == 'POST':
        j = request.json
        uri = j['image']
        url = "https://vision.googleapis.com/v1/images:annotate?key=AIzaSyB_0D0sJj_VkDitahThXTHtCyZBbiQUnds"
        jso = {
  "requests": [
    {
      "image": {
        "source": {
          "imageUri": uri
        }
      },
      "features": [
        {
          "type": "TEXT_DETECTION"
        }
      ],
      "imageContext": {
        "languageHints": [
          "hi"
        ]
      }
    }
  ]
}
        r = requests.post(url = url, json = jso)
        data = r.json()
        val = data['responses'][0]['textAnnotations'][0]['description']
        dat = translate_text("en", val)
        j = {"text":dat}
        res =  json.dumps(j)
        return res
    else:
        return "Post Your Request"


if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8255)
