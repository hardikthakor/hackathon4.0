from flask import Flask, request, jsonify, render_template
from boto.s3.key import Key
from boto.s3.connection import S3Connection
import base64
import json
import requests

app = Flask(__name__)

AWS_KEY = 'AKIAIZ2FYUKNDQAH6WUQ'
AWS_SECRET = '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'
REGION_HOST = 's3.us-west-2.amazonaws.com'
aws_connection = S3Connection(AWS_KEY, AWS_SECRET,host=REGION_HOST)
bucket = aws_connection.get_bucket("rhack")
@app.route('/s3upload',methods = ['POST', 'GET'])
def s3upload():
    print('okkkkkk')
    try: 

        if request.method == 'POST':

            j = request.json
            img = j['imageByte']
            imageUrl1 = img.encode("utf-8")
            with open("decodeimg.jpg", "wb") as fh:
                fh.write(base64.decodebytes(imageUrl1))


            key_obj = Key(bucket)

            ## set filename
            key_obj.key = j["filename"]  # upload name
            ## set data from an existing file
            key_obj.set_contents_from_filename("decodeimg.jpg")
            key_obj.set_acl('public-read')
            imageUrl = key_obj.generate_url(expires_in=0, query_auth=False)
            print(imageUrl)
            data = {"image" : imageUrl}
            rjson = json.dumps(data)
            if j["type"] == "monument":
                url = "http://52.187.6.152:8011/landmark"
                headers = {'Content-type': 'application/json'}
                resp = requests.post(url, data=json.dumps(data), headers=headers)
                print(resp.text)
                return resp.text
            if j["type"] == "signBoard":
                url = "http://52.187.6.152:8255/sign"
                headers = {'Content-type': 'application/json'}
                resp = requests.post(url, data=json.dumps(data), headers=headers)
                print(resp.text)
                return resp.text
        else:
            return "get"
    except Exception as e:
        print(e)
        pass
if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8017)
