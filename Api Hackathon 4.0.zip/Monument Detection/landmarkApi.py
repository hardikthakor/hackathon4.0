from flask import Flask, request, jsonify, render_template
from google.cloud import vision
import io
#from google.cloud.speech import enums
from google.cloud.vision import types
import requests
import json
import openpyxl
import urllib
app = Flask(__name__)

def detect_landmarks_uri(uri):
    """Detects landmarks in the file located in Google Cloud Storage or on the
    Web."""
    j= {}
    client = vision.ImageAnnotatorClient()
    image = types.Image()
    image.source.image_uri = uri

    response = client.landmark_detection(image=image)
    #print(response)
    landmarks = response.landmark_annotations
    print('Landmarks:')
    j={}
    
    for landmark in landmarks:
        print(landmark.description)
        index = 0
        for location in landmark.locations:
            lat_lng = location.lat_lng
            lat = str(lat_lng).split("\n")
            index += 1
            if index == 2:
                break
    
    lat=lat[0].split(":")
    latitude = lat[1]
    long=lat[1].split(":")
    longitude = long[0]
    print(longitude)
    book = openpyxl.load_workbook('Rajasthan latlong.xlsx')
    sheet = book.active
    a1 = sheet['J']
    a2 = sheet['A']
    count = 1
    for i in a2:
        #print(i.value)
        count += 1
        st = landmark.description
	print(st)
        if i.value == st.title():
	    print("ok")
            a3 = sheet.cell(row=count, column=10)
    val = a3.value
    val = val.encode('ascii', 'ignore').decode('ascii')
    j= {"place":landmark.description,"latitude": latitude.strip(),"longitude" : longitude.strip(),"desc" : str(val)}
    
    return j

@app.route('/landmark',methods = ['POST', 'GET'])
def landmark():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        url = j['image']
        dat = detect_landmarks_uri(url)
        j = json.dumps(dat)
        
        
        
        
        
        return j
    else:
        return "Post Your Request"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8011)


