import argparse
from google.cloud import translate
import six
from flask import Flask, request, jsonify, render_template
import json
from google.cloud import speech
from google.cloud.speech import enums
from google.cloud.speech import types
import io
import requests
import os
import urllib as u
from pydub import AudioSegment
import subprocess



app = Flask(__name__)
def download_audio(uri,):


    #outfname = "son.wav" 
    #if os.path.isfile(outfname):
    #os.remove(outfname)

    url = uri
    u.urlretrieve(url, "av1.wav")
    #subprocess.call(['ffmpeg', '-i', 'av1.m4a', 'son.wav'])
    print("pk")
    sound = AudioSegment.from_file("av1.wav")
    sound = sound.set_channels(1)
    sound.export("out1.wav", format="wav")
    print("1")
def transcribe_file(speech_file,sourceLang):
    """Transcribe the given audio file."""
    lang = sourceLang
    client = speech.SpeechClient()

    with io.open(speech_file, 'rb') as audio_file:
        content = audio_file.read()

    audio = types.RecognitionAudio(content=content)
    config = types.RecognitionConfig(
        encoding=enums.RecognitionConfig.AudioEncoding.LINEAR16,
        sample_rate_hertz=44100,
        language_code= lang
        )
    
    response = client.recognize(config, audio)
    
    # Each result is for a consecutive portion of the audio. Iterate through
    # them to get the transcripts for the entire audio file.
    for result in response.results:
        # The first alternative is the most likely one for this portion.
        print(result.alternatives[0].transcript)
    voiceTranslate = result.alternatives[0].transcript
    return voiceTranslate



def translate_text(target, text):

    translate_client = translate.Client()

    if isinstance(text, six.binary_type):
        text = text.decode('utf-8')

    # Text can also be a sequence of strings, in which case this method
    # will return a sequence of results for each text.
    result = translate_client.translate(
        text, target_language=target)
    translated = u'{}'.format(result['translatedText'])

    return translated

@app.route('/translateApp',methods = ['POST', 'GET'])
def translateApp():
    print('okkkkkk')
    if request.method == 'POST':
        val = {}
        j = request.json
        lang = j['language']
        uri = j['uri']
        sourceLang = j['srclanguage']
        download_audio(uri)
        print("2")
        txt = transcribe_file("out1.wav",sourceLang)
        print("3")
	val = translate_text(lang,txt)
        print("4")
        j = json.dumps({"text" : val})
        
        
        return j
    else:
        return "Post Your Request"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8012)




