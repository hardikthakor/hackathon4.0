import os
outfname = "son.wav"
if os.path.isfile(outfname):
    os.remove(outfname)
#os.system('avconv -i av1.m4a output.wav')
