var Sync = require('sync');
const download = require('image-downloader')
var fb = require('fb');
var fs = require('fs');
var exp = require('express');
var app = exp();
var Twitter = require('node-twitter');
var request = require('request');
app.use(exp.json());

if (fs.existsSync("cr7.jpg")) {   
fs.unlinkSync("cr7.jpg");
    // Do something
}

fb.setAccessToken('EAACEdEose0cBAKCcmi1BZBk2ivlkl7EPRZBFBAwQqXeuCEAbNZClJl3Jh7Qm6frbyr49q4sLU9MwsZCzMZBErKXGUKml0mHUyQcs2ASGxTFG7HcWl1KM1kJcEK4Dp1b2SqRHafK2IL2SZA2Kp2dZBKdV0DxvgZB0tlR2Yo6cZCSAREVvrBeOgKxZA48654qzTM9Wln1zVAV04UQwZDZD');

//twitter token id
var twitterRestClient = new Twitter.RestClient(
    'qpVLweTFnVfEp9j1BsY2koeZI',
    'svwWE0ZJjusDmVGLageGlFYPwkQHXQOFdkHwirhnZQmveisGfX',
    '955034718235316224-10m2sbjolt6D8Edj7UFIZyxduyivq1m',
    'vAp5iMiwMCRAsbpQuMdcioVE25zvc9w9R0OZQJEcqdq4D'
);

app.post('/upload', function (req, res) {
    console.log("Post Called....");
    //req = JSON.parse(req);
    console.log(req.body);
    var desc ="Authority Name : "+req.body.authUserName+ "\nType : "+req.body.type+"\nSeverity : "+req.body.priority+"\nDescription : "+req.body.description;

    const options = {
        //url: 'http://www.hotel-r.net/im/hotel/es/rock-star-8.jpg',
        url:req.body.AimageUrl,
        dest: 'cr7.jpg'                  // Save to /path/to/dest/image.jpg
    }

    function asyncFunction(a, b, callback) {
        process.nextTick(function(){
            download.image(options)
      .then(({ filename, image }) => {
        console.log('File saved to', filename)
        console.log('End Statement',a)
    
        var path = filename;
        fb.api('me/photos', 'post', { source : fs.createReadStream(path), caption: desc}, function (res) {
        if(!res || res.error) {
          console.log(!res ? 'error occurred' : res.error);
          return;
        }
        console.log('Post Id: ' + res.post_id);
       });
    
       twitterRestClient.statusesUpdateWithMedia(
        {
            'status': desc,
            'media[]': path
        },
        function(error, result) {
            if (error)
            {
                console.log('Error: ' + (error.code ? error.code + ' ' + error.message : error.message));
            }
     
            if (result)
            {
                console.log(result);
            }
        }
    );
    
      }).catch((err) => {
        throw err
      })
          
            callback(a+b);
        })
    }
     
    // Run in a fiber 
    Sync(function(){
     
        try {
            var result = asyncFunction.sync(null, 2, 3);
            console.log(result);
        }
        catch (e) {
            console.error(e); // something went wrong 
        }
    })
    

  console.log("Api Started .....");
  res.send('Posted Successfully');
});



var server = app.listen(8776, function () {

var host = server.address().address
 var port = server.address().port
 console.log("Example app listening at http://%s:%s", host, port)
})
