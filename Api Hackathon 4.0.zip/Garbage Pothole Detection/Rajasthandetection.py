from flask import Flask, request, jsonify, render_template
import requests
import mimetypes
import yaml
import urllib.request
import json
from PIL import Image
import pymongo
from pymongo import MongoClient
from boto.s3.connection import S3Connection
import boto3
import random
from boto.s3.key import Key
import base64
from datetime import datetime
import io
import os
from google.cloud import vision
from google.cloud.vision import types

app = Flask(__name__)

client = MongoClient('52.230.17.234',27017)
db = client['replica']
#result = []
AWS_KEY = 'AKIAIZ2FYUKNDQAH6WUQ'
AWS_SECRET = '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'
aws_connection = S3Connection(AWS_KEY, AWS_SECRET)
bucket = aws_connection.get_bucket("citizenserviceapp2")

@app.route('/detect',methods = ['POST', 'GET'])
def detect():
    print('okkkkkk')
    try: 

        if request.method == 'POST':
            j = request.json
            img = j['imageUrl']
            imageUrl1 = img.encode("utf-8")
            with open("decodeimg.jpg", "wb") as fh:
                fh.write(base64.decodebytes(imageUrl1))
        
            key_obj = Key(bucket)
            ts = str(datetime.now())


            ## set filename
            key_obj.key = j["userId"]+"/"+j["type"]+'-'+ts+'.jpg'  # upload name
            ## set data from an existing file
            key_obj.set_contents_from_filename("decodeimg.jpg")
            key_obj.set_acl('public-read')
            imageUrl = key_obj.generate_url(expires_in=0, query_auth=False)
            #urllib.request.urlretrieve(imageUrl, "dl1.jpg")
            j["imageUrl"] = imageUrl
            file = 'decodeimg.jpg'
            url1 = "http://52.230.17.234:8079/visionapi"
            data = {"imageUrl" : imageUrl}
            headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
            resp = requests.post(url1, data=json.dumps(data), headers=headers)
            k = resp.text
            print(k)
            if("fraud" in k):
                print("fraud")
                rdata = {"imageUrl" : imageUrl, "payLoad" : "fraud"}
                #rjson = json.dumps(rdata)
            elif("legal" in k):
                print("legal")
                f = Image.open(file)
                f1 = f.resize((1000,1000),Image.ANTIALIAS)
                f1.save("reqImage.jpg",quality=95)
                f1 = 'reqImage.jpg'
                url = 'https://southcentralus.api.cognitive.microsoft.com/customvision/v1.1/Prediction/720df90d-5f80-4e82-9e4c-aa6b42ffd43c/url?iterationId=e0b9c0d2-d089-475b-b9d9-b1bfe528c741'
                headers = {'Content-type': 'application/json', 'Accept': 'text/plain' , 'Prediction-Key' : 'b439bb19650f48128a7bc9d8dbc63e0f'}
                a = requests.post(url = url, data = json.dumps({"Url" : imageUrl}),headers = headers)
                s = yaml.load(a.text)
                r1 = s['Predictions'][0]['Tag']
                r2 = s['Predictions'][0]['Probability']
                r3 = s['Predictions'][1]['Tag']
                r4 = s['Predictions'][1]['Probability']
                print(r1)
                print(r2)
                print(r3)
                print(r4)

                if((r1 == 'gabage') and (r2 > 0.50)):
                    print("Grabage detected!!!!!!!!!!")
                    rdata = {"imageUrl" : imageUrl, "payLoad" : "Garbage"}
                    #rjson = json.dumps(rdata)
                elif(j["type"]=="garbage"):
                    print("ncaffe")
                    url2= 'http://52.187.162.152:8080/caffeTest'
                    data2 ={"imageUrl" : imageUrl}
                    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
                    resp = requests.post(url2, data=json.dumps(data2), headers=headers)
                    print(resp.text.split('"')[1])
                    
                    if((resp.text.split('"')[1] == "Garbage")): #and (r4 > 0.20)):
                        rdata = {"imageUrl" : imageUrl, "payLoad" : "Garbage"}
                    else:
                        urlp = 'https://southcentralus.api.cognitive.microsoft.com/customvision/v1.1/Prediction/84286f96-172b-48c4-bf44-bd1c2befe765/url?iterationId=d98ff001-ab48-43b8-811e-d29bd4417240'
                        headers = {'Content-type': 'application/json', 'Accept': 'text/plain' , 'Prediction-Key' : 'b439bb19650f48128a7bc9d8dbc63e0f'}
                        ap = requests.post(url = urlp, data = json.dumps({"Url" : imageUrl}),headers = headers)
                        sp = yaml.load(a.text)
                        r1p = sp['Predictions'][0]['Tag']
                        r2p = sp['Predictions'][0]['Probability']
                        r3p = sp['Predictions'][1]['Tag']
                        r4p = sp['Predictions'][1]['Probability']
                        #rjson = json.dumps(rdata)
                        print(r1p)
                        print(r2p)
                        print(r3p)
                        print(r4p)
                        if((r1p == 'pothole') and (r2 > 0.50)):
                            print("Pothole detected!!!!!!!!!!")
                            rdata = {"imageUrl" : imageUrl, "payLoad" : "Pothole"}
                        else:    
                            rdata = {"imageUrl" : imageUrl, "payLoad" : "Wrong"}
            

                if((rdata["payLoad"] == "Garbage") and (rdata["payLoad"] == "Pothole")):
                    urlDup = 'http://52.230.17.234:8089/api'
                    headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
                    data = {"longitude" : j['longitude'], "latitude" : j["latitude"], "type" : j["type"]} 
                    response = requests.post(urlDup, data=json.dumps(data), headers=headers)
                    if("success" in response.text):
                        db.insertions.insert(j)
                    else:
                        rdata = {"imageUrl" : imageUrl, "payLoad" : "duplicate"}
                        #rjson = json.dumps(rdata)
        #else:
            #bucket.delete_key(key_obj)
            rjson = json.dumps(rdata)    
            return rjson
        else:
            return "get"
    except Exception as e:
        print(e)
        pass

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8778)