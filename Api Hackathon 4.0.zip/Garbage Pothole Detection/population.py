from flask import Flask, request, jsonify, render_template
import pymongo
from pymongo import MongoClient
import json

app = Flask(__name__)


client = MongoClient('52.230.17.234',27017)
db = client['Population']


@app.route('/population',methods = ['POST', 'GET'])
def population():
    print('okkkkkk')
    if request.method == 'POST':
        j =  request.json
        for obj in db.pops.find({"pincode": j['pincode']}):
            if("_id" in obj):
                del obj["_id"]
            pops = obj["population"]
        rjson = json.dumps(pops)
        return rjson.split('"')[1]
    else:
        return "Get Your Request"
if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8466, threaded=True)