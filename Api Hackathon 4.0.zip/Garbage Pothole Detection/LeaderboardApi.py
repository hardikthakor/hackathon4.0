from flask import Flask, request, jsonify, render_template
import requests
import urllib.request
import json
import pymongo
from pymongo import MongoClient
import random
import boto3

client = MongoClient('52.230.17.234',27017)
db = client['userDetails']
result = []
app = Flask(__name__)



@app.route('/leaderBD',methods = ['POST', 'GET'])
def leaderBD():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        for obj in db.data.find({"profEmail": j["userId"]}):
            a = obj
        if j['priority'] == "High":
            a["points"] = int(a["points"]) + 300
        elif j['priority'] == "Medium":
            a["points"] = int(a["points"]) + 200
        else:
            a["points"] = int(a["points"]) + 100 
        #a["points"] = int(a["points"]) + 300
        if "counter" in a:
            print("counter present")
        else:
            a["counter"] = str(0)
        c = int(a["points"]/1000)
        if c > int(a["counter"]):
            code_chars = '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ'
            code = ''
            for i in range(0, 8):
                slice_start = random.randint(0, len(code_chars) - 1)
                code += code_chars[slice_start: slice_start + 1]
            print(code)
            a["promocode"] = code
            #msg code here
            email_receiver = "pachanganemayu@gmail.com"
            message_email = "Flat Rs.100 Cash on paytm on the basis of points rewarded. Use PROMOCODE:- "+ code +" Go to the paytm website now! https://paytm.com/ #CitizenServiceApp #PaytmKaro"
            number = "8888432018"
            message_phone = "Flat Rs.100 Cash on paytm on the basis of points rewarded. Use PROMOCODE:- "+ code +" Go to the paytm website now! https://paytm.com/ #CitizenServiceApp #PaytmKaro"
          
            conn1 = boto3.client(
                'sns',
                aws_access_key_id='AKIAJDANOYWK27LWYU3Q',
                aws_secret_access_key='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',
                region_name = "us-west-2" #oregon
            )

            conn1.publish(
                PhoneNumber = "+91"+number,
                Message = message_phone
            )

            conn = boto3.client('ses',
                                aws_access_key_id='AKIAJDANOYWK27LWYU3Q',
                                aws_secret_access_key='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',
                                region_name = "us-west-2"
            )
            conn.send_email(
                Source="hardikthakor.ht@gmail.com",
                Destination={
                   'ToAddresses': [
                        email_receiver
                    ]
                },
                Message={
                   'Subject': {
                        'Data': 'Citizen Service',
                        'Charset': 'UTF-8'
                    },
                    'Body': {
                       'Text': {
                           'Data': message_email,
                           'Charset': 'UTF-8'
                        }
                    }
                }
            )
            a["counter"] = str(int(a["counter"]) + 1)
        a["complaintsCount"] = str(int(a["complaintsCount"]) + 1)
        db.data.remove({"profName" : a["profName"]})
        db.data.insert(a)
        print("All operations Done!!!!!!!!!!!!!!!!!!!!!!!!!!")
        
        return "ok"
    else:
        return "get"
if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8003, threaded=True)


