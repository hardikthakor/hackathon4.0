from flask import Flask, request, jsonify, render_template
import pymongo
from pymongo import MongoClient
import json
import requests
app = Flask(__name__)

client = MongoClient('52.230.17.234',27017)
db = client['userDetails']
#result = []

@app.route('/register',methods = ['POST', 'GET'])
def register():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        count = db.data.find({"profEmail" : j['profEmail']}).count()
        print(count)
     
        url = 'http://52.230.17.234:8002/ejabadd'
        print(j)        
        data = {"jabberId" : j['jabberId']}
        print(data)
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        response = requests.post(url, data=json.dumps(data), headers=headers)
        print(response)
        if(count == 0):
            db.data.insert(j)
        else:
            '''for obj in db.data.find({"profEmail" : j['profEmail']}):
                result.append(obj)
            r = result[0]
            r['tokenId'] = j['tokenId']
            del r['_id']'''
            db.data.update({"profEmail" : j['profEmail']},{"$set":{"deviceId" : j['deviceId'],"profUrl":j['profUrl']}})
            #result.pop(0)

        return "Registered"
    else:
        return "get"




if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8006, threaded=True)
