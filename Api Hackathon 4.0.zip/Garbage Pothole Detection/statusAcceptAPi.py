from flask import Flask, request, jsonify, render_template
import pymongo
from pymongo import MongoClient
import json

app = Flask(__name__)

client = MongoClient('52.230.17.234',27017)
db = client['replica']
result = []

@app.route('/statusAccept',methods = ['POST', 'GET'])
def statusAccept():
    print('okkkkkk')
    if request.method == 'GET':
        
        count = db.accept.find().count()
        for obj in db.accept.find():
            del obj['_id']
            result.append(obj)

        rjson = json.dumps(result)
            

        return rjson
    else:
        return "post"




if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8007, threaded=True)