from flask import Flask, request, jsonify, render_template
import requests
import yaml
import urllib.request
import json


app = Flask(__name__)



@app.route('/garbsever',methods = ['POST', 'GET'])
def garbsever():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        imageUrl = j['imageUrl']
        print(imageUrl)
        urllib.request.urlretrieve(imageUrl, "dl1.jpg")
        file = 'dl1.jpg'
        
        url1 = "https://api.vize.ai/v1/classify/"
        files = {'image_file': open(file, 'rb')} #use path to your image

        headers = {"Authorization": "Token 70b39796d6e223c121d86a542eb100d7b9b2e09a"}
        data = {'task': 'ecc8fbe1-aaae-4a09-8a34-5e6f23d78fc1'}

        response = requests.post(url1, headers=headers, files=files, data=data)
        print(response.text)
        resp = response.text
        d = yaml.load(resp)
        print(d["best_label"]["label_name"])
        #print("ok till here",d)
        rdata = {"imageUrl" : imageUrl, "payLoad" : d["best_label"]["label_name"]}
        rjson = json.dumps(rdata)
 
        return rjson
    else:
        return "get"



@app.route('/potsever',methods = ['POST', 'GET'])
def potsever():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        imageUrl = j['imageUrl']
        urllib.request.urlretrieve(imageUrl, "dl1.jpg")
        file = 'dl1.jpg'
        #print("Pothole detected!!!!!!!!!!")
        url1 = "https://api.vize.ai/v1/classify/"
        files = {'image_file': open(file, 'rb')} #use path to your image

        headers = {"Authorization": "Token 70b39796d6e223c121d86a542eb100d7b9b2e09a"}
        data = {'task': '7ef45544-0b9c-40c8-a224-f6312cc31484'}

        response = requests.post(url1, headers=headers, files=files, data=data)
        print(response.text)
        resp = response.text
        d = yaml.load(resp)
        #print(d['prediction'])
        rdata = {"imageUrl" : imageUrl, "payLoad" : d["best_label"]["label_name"]}
        rjson = json.dumps(rdata)
         
        return rjson
    else:
        return "get"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8080, threaded=True)
