
from flask import Flask, request, jsonify, render_template
import pymongo
from pymongo import MongoClient
import json

app = Flask(__name__)

client = MongoClient('52.230.17.234',27017)
db = client['replica']
result = []

@app.route('/authcompaccept/<string:authUserName>/<int:pincode>',methods = ['POST', 'GET'])
def authcompaccept(authUserName,pincode):
    print('okkkkkk')
    if request.method == 'GET':

        print(authUserName)
        print(pincode)
        count = db.accept.find({"authUserName" : authUserName, "pincode": str(pincode)}).count()
        if(count != 0):
            for obj in db.accept.find({"authUserName" : authUserName, "pincode": str(pincode)}):
                if("_id" in obj):
                    del obj["_id"]
                result.append(obj)
            print(result)   
            rjson = json.dumps(result)
            result.clear()
        else:
            rjson = json.dumps({"flag": "null"})            
        return rjson
    else:
        return "Get Your Request"
if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8124, threaded=True)
