from flask import Flask, request, jsonify, render_template
import pymongo
from pymongo import MongoClient
import json

app = Flask(__name__)

client = MongoClient('52.230.17.234',27017)
db = client['replica']
result = []

@app.route('/usercompaccept',methods = ['POST', 'GET'])
def usercompaccept():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        count = db.accept.find({"userId" : j["userId"]}).count()
        print(count)
        if(count != 0):
            for obj in db.accept.find({"userId" : j["userId"]}):
                if("_id" in obj):
                    del obj["_id"]
                result.append(obj)
               
            rjson = json.dumps(result)
            result.clear()
        else:
            rjson = json.dumps({"flag": "null"})            
        return rjson
    else:
        return "Post Your Request"


if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8125, threaded=True)
