var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require("mongoose");
var redis = require('redis');
var schedule    = require('node-schedule');
var JSONStore = require('redis-json');
var cron = require('cron');
//var redis = new Redis();
var client = redis.createClient(6379, '52.230.17.234');
var jsonStore = new JSONStore(client);
 

//app.use(bodyParser.json({type : "application/json"}));

app.use(express.json());       // to support JSON-encoded bodies 
/*app.post('/addUser', function (req, res) {
    console.log(req.body.imagrUrl);
       res.end( JSON.stringify(data));
   
})*/

app.get('/api/', function (req, res) {  
  
     console.log("Get Called ...");
    
    res.send("Welcome To Rockstar Research Lab");  
  
  });


app.post('/api/', function (req, res) {  
  var reply;
  
  mongoose.connect("mongodb://52.230.17.234/replica");
  console.log(req.body);
  var Schema = mongoose.Schema;
  
  var userSchema = new Schema({
    image_id:String,
    name:String,
    email:String,
    mobile:String
  });
var job = new cron.CronJob('*/1 * * * *', function() {  
  console.log('Function executed!');

  var userModel;
  if (mongoose.models.userModel) {
    userModel = mongoose.model("abcs");
  }
  else {
     userModel = mongoose.model("abcs",userSchema);
  }
 
  userModel.find(function(err,userObj){

    if(err){
      context.done();
      console.log(err);
      reply = err;
    }
    
    else{
      console.log("Found :",userObj);
      reply = userObj;
      client.flushdb( function (err, succeeded) {
        console.log(succeeded); // will be true if successfull
      });
      
      var id =0;
      var json1 =[];
      userObj.forEach(function(iter){
        id++;
        var abc= "hello";
        abc= abc+ id;
       
        //console.log(iter);

       /*jsonStore.set(abc, iter.toString(), function(err, result){
        console.log(err, result);
        });*/
        client.set(abc,JSON.stringify(iter));
        //client.set(abc,iter.toString());
        //client.get(abc,function(err,result){result=JSON.parse(result);json1.push(result)});
        
      })
      console.log(json1)
      //res.send(json1);
      
      
      delete mongoose.connection.models['abcs'];
      
    }
  });
}, null, true);
  
	
  //res.send(reply);

});

var server = app.listen(8889, function () {

 var host = server.address().address
  var port = server.address().port
  console.log("Example app listening at http://%s:%s", host, port)
})
