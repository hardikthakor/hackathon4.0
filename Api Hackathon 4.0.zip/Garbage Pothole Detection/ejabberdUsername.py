from flask import Flask, request, jsonify, render_template
import requests
from requests.auth import HTTPBasicAuth
import urllib.request
import json


app = Flask(__name__)




@app.route('/ejabadd',methods = ['POST', 'GET'])
def ejabadd():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        server = "ejabberd_New"
        virtualhost = "localhost"
        url = "http://54.200.135.120:5280/admin/server/localhost/users/" . format (server, virtualhost)
        auth = HTTPBasicAuth("admin@localhost", "password")
        data = {
            'newuserpassword': "12345",
            'addnewuser': "Add User"
        }
        a = j["jabberId"]
        b = a.split("@")
        data['newusername'] = b[0]
        resp = requests.post(url, data=data, auth=auth)


        assert resp.status_code == 200
        return "ok"
    else:
        return "get"



if __name__ == '__main__':
   app.run(debug = True, host='0.0.0.0', port=8002, threaded=True)
