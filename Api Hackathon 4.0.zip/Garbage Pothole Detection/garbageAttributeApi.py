from flask import Flask, request, jsonify, render_template
from scipy.spatial import distance as dist
from imutils import perspective
from imutils import contours
import numpy as np
import argparse
import imutils
import cv2
import json
import operator
from boto.s3.connection import S3Connection
from boto.s3.key import Key
import urllib.request
import requests

app = Flask(__name__)


def midpoint(ptA, ptB):
    return ((ptA[0] + ptB[0]) * 0.5, (ptA[1] + ptB[1]) * 0.5)# load the image, convert it to grayscale, and blur it slightly

@app.route('/garbageAttributeApi',methods = ['POST','GET'])
def garbageAttributeApi():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        pin = j["pincode"]
        r = requests.get(url = "http://18.219.145.80:8466/population", params = {"pincode" : pin})

        im = j["imageUrl"]
        urllib.request.urlretrieve(im, "2.jpg")
        image = cv2.imread('2.jpg')
        t = 160
        width = 1
        
        # create binary image
        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        blur = cv2.GaussianBlur(gray, (5, 5), 0)
        (t, binary) = cv2.threshold(blur, t, 255, cv2.THRESH_BINARY)

        # perform edge detection, then perform a dilation + erosion to
        # close gaps in between object edges
        edged = cv2.Canny(gray, 50, 100)
        edged = cv2.dilate(edged, None, iterations=1)
        edged = cv2.erode(edged, None, iterations=1)

        # find contours in the edge map
        cnts = cv2.findContours(edged.copy(), cv2.RETR_EXTERNAL,cv2.CHAIN_APPROX_SIMPLE)
        cnts = cnts[0] if imutils.is_cv2() else cnts[1]

        # sort the contours from left-to-right and initialize the
        # 'pixels per metric' calibration variable
        (cnts, _) = contours.sort_contours(cnts)
        pixelsPerMetric = None

        #declre dictionaries
        dimena = {}
        dimenb = {}
        area = {}
        counter = 1

        # loop over the contours individually
        for c in cnts:
            # if the contour is not sufficiently large, ignore it
            if cv2.contourArea(c) > 100:
                continue

            # compute the rotated bounding box of the contour
            orig = image.copy()
            box = cv2.minAreaRect(c)
            box = cv2.cv.BoxPoints(box) if imutils.is_cv2() else cv2.boxPoints(box)
            box = np.array(box, dtype="int")

            # order the points in the contour such that they appear
            # in top-left, top-right, bottom-right, and bottom-left
            # order, then draw the outline of the rotated bounding
            # box
            box = perspective.order_points(box)
            cv2.drawContours(orig, [box.astype("int")], -1, (0, 255, 0), 2)

            # loop over the original points and draw them
            for (x, y) in box:
                cv2.circle(orig, (int(x), int(y)), 5, (0, 0, 255), -1)

            # unpack the ordered bounding box, then compute the midpoint
            # between the top-left and top-right coordinates, followed by
            # the midpoint between bottom-left and bottom-right coordinates
            (tl, tr, br, bl) = box
            (tltrX, tltrY) = midpoint(tl, tr)
            (blbrX, blbrY) = midpoint(bl, br)

            # compute the midpoint between the top-left and top-right points,
            # followed by the midpoint between the top-righ and bottom-right
            (tlblX, tlblY) = midpoint(tl, bl)
            (trbrX, trbrY) = midpoint(tr, br)

            # compute the Euclidean distance between the midpoints
            dA = dist.euclidean((tltrX, tltrY), (blbrX, blbrY))
            dB = dist.euclidean((tlblX, tlblY), (trbrX, trbrY))

            # if the pixels per metric has not been initialized, then
            # compute it as the ratio of pixels to supplied metric
            # (in this case, inches)
            if pixelsPerMetric is None:
                pixelsPerMetric = dB / width

            # compute the size of the object
            dimA = dA / pixelsPerMetric
            dimB = dB / pixelsPerMetric
            
            #save values in dictionaries
            dimena[counter] = dimA
            dimenb[counter] = dimB
            area[counter] = dimA*dimB
            counter += 1

        maxarea = max(area, key=area.get)

        mlength1 = dimena[maxarea]
        mlength2 = dimenb[maxarea]
        marea = area[maxarea]
        mperi = (2*mlength1)+(2*mlength2)
        if mlength1 < mlength2:
            mvolume = marea* mlength1/2
        else:
            mvolume = marea* mlength2/2
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
        population = requests.post(url = "http://18.219.145.80:8466/population", data = json.dumps({"pincode" : pin}),headers = headers)
  #  a = request.json
   # population = a["population"]
        return jsonify({"length1" : mlength1,"length2" : mlength2,"area" : marea,"peri" : mperi, "volume" : mvolume, "population" : population.text})
    
if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8080)