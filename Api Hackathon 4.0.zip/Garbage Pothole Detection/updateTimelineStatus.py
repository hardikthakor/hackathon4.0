from flask import Flask, request, jsonify, render_template
import pymongo
from pymongo import MongoClient
import json
#import requests

app = Flask(__name__)

client = MongoClient('52.230.17.234',27017)
db = client['replica']
#result = []

@app.route('/timeline',methods = ['POST', 'GET'])
def timeline():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        for obj in db.accept.find({"complaintTitle" : j['complaintTitle']}):
            a = obj
        timelineStatus = int(a['timelineStatus']) + 1
        
        db.accept.update({"complaintTitle" : j['complaintTitle']},{"$set":{"timelineStatus" : str(timelineStatus)}})
        

        return "updated"
    else:
        return "get"




if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8130, threaded=True)
