
# coding: utf-8

# In[6]:


import pymongo
from pymongo import MongoClient
import requests
import json
import yaml


# In[7]:


client = MongoClient('52.230.17.234',27017)


# In[8]:


db = client['replica']
db1 = client['pAuthorityDetails']
db2 = client['gAuthorityDetails']
#url = 'http://ES_search_demo.com/document/record/_search?pretty=true'
result = []
auth = []
registration_ids = []


# In[9]:


while True:
    try :
        
        if db.insertions.find({}).count() > 0:
            print("Yes")
            for obj in db.insertions.find():
                result.append(obj)
            #print(result[0])
            count = db.insertions.find({}).count()
            print(count)
            for i in range(0,count):
                a = result[0]
                #back up the data
                if("_id" in a):
                    del a['_id']
                db.backups.insert(a)
                #db.bios.remove(a)
                #calling severeness api
                if a["type"] == "garbage":
                    url = 'http://52.230.17.234:8555/severity'
                elif a["type"] == "pothole":
                    url = 'http://52.230.17.234:8666/severity'
                print(url)
                data = {"imageUrl" : a['imageUrl']}
                print(data)
                headers = {'Content-type': 'application/json', 'Accept': 'text/plain'}
                response = requests.post(url, data=json.dumps(data), headers=headers)
                print("OK till here")
                print(response.text)
                resp = response.text
                r = yaml.load(resp)
                b = a
                b['priority'] = r['payLoad']
                #print(b["pincode"])
                pin = b["pincode"]
                print(type(pin))
                #authorize = db.authorities.find({"pincode" : pincode["postcode"]})
                if(b['type']=='garbage'):
                    print("garbage")
                    for ob in db2[pin].find():
                        #ob = list(db.authorities.find({"pincode" : "401203"}))
                        print("auth found = ",ob)
                        auth.append(ob)
                        registration_ids.append(ob['tokenId'])
                        #registration_ids.append(b['deviceId'])
                elif(b['type'] == 'pothole'):
                    print("pothole")
                    for ob in db1[pin].find():
                        #ob = list(db.authorities.find({"pincode" : "401203"}))
                        print("auth found = ",ob)
                        #auth.append(ob)
                        registration_ids.append(ob['tokenId'])
                        #registration_ids.append(b['deviceId'])
                print(registration_ids)
                if("_id" in b):
                    del b['_id']
                url2 = 'https://fcm.googleapis.com/fcm/send'
                #headers = {"Content-Type": "application/json","Authorization": "key=AIzaSyBp0LK2dSzS9E6ewJ-oX-w7hu8d-RCvFQY"}
                headers = {'Authorization': 'key=AIzaSyBp0LK2dSzS9E6ewJ-oX-w7hu8d-RCvFQY', 'Content-Type': 'application/json'}
                data2 = {
                        "registration_ids" : registration_ids,
                        "collapse_key" : "type_a",
                        "notification" : {
                                        "body" : "New Issue Generated",
                                        "title": "New Notification",
                                        "click_action":"android.intent.action.ALL_APPS"
                                        },
                        "data" : {
                                "k" : b
                                
                                }
                        }
                res = requests.request("POST", url2, json=data2, headers=headers)
                print(res.text)
                registration_ids.clear()
                print(registration_ids)
                url1 = 'http://52.230.17.234:8003/leaderBD'
                data1 = b
                headers = {'Content-type': 'application/json', 'Accept':'text/plain'}
                response = requests.post(url1, data=json.dumps(data1), headers=headers)
                db.rejects.insert(b)
                rm = {"latitude": a['latitude'], "longitude": a["longitude"]}
                db.insertions.remove(rm)
                print("Done all operations")
                result.pop(0)
    except Exception as e: 
        print(e)
        print("error")

# In[ ]:




