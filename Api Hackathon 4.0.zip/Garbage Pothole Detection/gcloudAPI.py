from flask import Flask, request, jsonify, render_template
import urllib.request
import json
import io
import os
from google.cloud import vision
from google.cloud.vision import types

app = Flask(__name__)

client = vision.ImageAnnotatorClient()

@app.route('/visionapi',methods = ['POST', 'GET'])
def visionapi():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        imageUrl = j['imageUrl']
        urllib.request.urlretrieve(imageUrl, "dl2.jpg")
        file = "dl2.jpg"
        with io.open(file, 'rb') as image_file:
            content = image_file.read()
        image = types.Image(content=content)

        response = client.web_detection(image=image)
        n = len(response.web_detection.partial_matching_images)
        n1 = len(response.web_detection.full_matching_images)
        print(response)
        if((n == 0) and (n1 == 0)):
            print("legal")
            rdata = {"imageUrl" : imageUrl, "payLoad" : "legal"}
            rjson = json.dumps(rdata)
        else:
            print("fraud")
            rdata = {"imageUrl" : imageUrl, "payLoad" : "fraud"}
            rjson = json.dumps(rdata)

        return rjson
    else:
        return "get"


if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8079, threaded=True)
