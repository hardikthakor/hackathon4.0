from flask import Flask, request, jsonify, render_template
import pymongo
from pymongo import MongoClient
import json
from boto.s3.connection import S3Connection
import boto3
import random
from boto.s3.key import Key
import base64
from datetime import datetime
import requests
app = Flask(__name__)

client = MongoClient('52.230.17.234',27017)
db = client['replica']
result = []
AWS_KEY = 'AKIAIZ2FYUKNDQAH6WUQ'
AWS_SECRET = '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'
aws_connection = S3Connection(AWS_KEY, AWS_SECRET)
bucket = aws_connection.get_bucket("citizenserviceapp2")

@app.route('/imageComp',methods = ['POST', 'GET'])
def imageComp():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        img = j['AimageUrl']
        imageUrl1 = img.encode("utf-8")
        with open("decodeimg1.jpg", "wb") as fh:
            fh.write(base64.decodebytes(imageUrl1))
        
        key_obj = Key(bucket)
        ts = str(datetime.now())
        print(j)
        print(type(j["latitude"]))
        ## set filename
        key_obj.key = j["authUserName"]+"/"+j["type"]+'-'+ts+'.jpg'  # upload name
        ## set data from an existing file
        key_obj.set_contents_from_filename("decodeimg1.jpg")
        key_obj.set_acl('public-read')
        imageUrl = key_obj.generate_url(expires_in=0, query_auth=False)
        #urllib.request.urlretrieve(imageUrl, "dl1.jpg")
        j["AimageUrl"] = imageUrl
        count = db.accept.find({"latitude" : j["latitude"],"longitude" : j["longitude"],"type" : j["type"],"complaintTitle": j["complaintTitle"]}).count()
        print(count)
        if(count != 0):
            for obj in db.accept.find({"latitude" : j["latitude"],"longitude" : j["longitude"],"type" : j["type"],"complaintTitle": j["complaintTitle"]}):
                if("_id" in obj):
                    del obj["_id"]
                result.append(obj)
            a = result[0]
            lat = int(float(a["latitude"]))
            lon = int(float(a["longitude"]))
            #lat1 = int(lat * 100)/100
            #lon1 = int(lon * 100)/100
            print(lat)
            print(lon)
            if((int(float(j["Alatitude"])) == lat) and (int(float(j["Alongitude"])) == lon)):

                a["Alatitude"] = j["Alatitude"]
                a["Alongitude"] = j["Alongitude"] 
                a["AimageUrl"] = j["AimageUrl"]
                if('_id' in a):
                    del a['_id']
                db.abcs.insert(a)
                db.accept.remove({"complaintTitle" : j["complaintTitle"]})
                url1 = 'http://52.230.17.234:8886/AleaderBD'
                data1 = a
                if('_id' in data1):
                    del data1['_id']
                headers = {'Content-type': 'application/json', 'Accept':'text/plain'}
                response = requests.post(url1, data=json.dumps(data1), headers=headers)
                rjson = json.dumps({"flag": "success"})
                url3 = 'http://52.230.17.234:8776/upload'
     
                headers = {'Content-type': 'application/json', 'Accept':'text/plain'}
                response1 = requests.post(url3, data=json.dumps(data1), headers=headers)
                print(response1.text)
                result.clear()
            else:
                rjson = json.dumps({"flag": "null"}) 
        else:
            rjson = json.dumps({"flag": "null"})     
        print (rjson)           
        return rjson
    else:
        return "Post Your Request"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8887, threaded=True)
