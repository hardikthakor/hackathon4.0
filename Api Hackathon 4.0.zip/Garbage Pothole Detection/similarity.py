from flask import Flask, request, jsonify, render_template
from skimage.measure import compare_ssim
import argparse
import imutils
import cv2
from PIL import Image
from resizeimage import resizeimage
import urllib.request

app = Flask(__name__)



@app.route('/similarity',methods = ['POST', 'GET'])
def similarity():
    print('okkkkkk')
    if request.method == 'POST':
        a = request.json
        url1 = a['custIMG']
        url2 = a['authIMG']
        urllib.request.urlretrieve(url1, "j1.jpg")
        urllib.request.urlretrieve(url2, "j2.jpg")

        with open('j1.jpg', 'r+b') as f:
            with Image.open(f) as image:
                cover = resizeimage.resize_cover(image, [500, 300])
                cover.save('judva1.jpg', image.format)
        with open('j2.jpg', 'r+b') as f:
            with Image.open(f) as image:
                cover = resizeimage.resize_cover(image, [500, 300])
                cover.save('judva2.jpg', image.format)

        imageA = cv2.imread("judva1.jpg")
        imageB = cv2.imread("judva2.jpg")

        # convert the images to grayscale
        # next line make error
        # OpenCV Error: Assertion failed (scn == 3 || scn == 4) in cvtColor
        grayA = cv2.cvtColor(imageA, cv2.COLOR_BGR2GRAY)
        grayB = cv2.cvtColor(imageB, cv2.COLOR_BGR2GRAY)

        # compute the Structural Similarity Index (SSIM) between the two
        # images, ensuring that the difference image is returned
        (score, diff) = compare_ssim(grayA, grayB, full=True)
        diff = (diff * 255).astype("uint8")
        if float(format(score)) >= 0.4000 :
            return jsonify({"result" : "true"})
        else:
            return jsonify({"result" : "false"})
       
    else:
        return "get"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8080)