from flask import Flask, request, jsonify, render_template
import pymongo
from pymongo import MongoClient
import json
import requests
from datetime import datetime  
from datetime import timedelta

app = Flask(__name__)

client = MongoClient('52.230.17.234',27017)
db = client['replica']
db1 = client['gAuthorityDetails']
db2 = client['pAuthorityDetails']
result = [0]
m = ['null','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']

@app.route('/accept',methods = ['POST', 'GET'])
def accept():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        print (j) 
        count = count = db.rejects.find({"complaintTitle" : j['complaintTitle']}).count()
        if (count != 0):
            if(j["type"] == 'garbage'):
                print("garbage")
                for obj in db1[j["pincode"]].find({"authUserName" : j['authUserName']}):
                    #result.append(obj)
                    result[0] = obj
            elif(j["type"] == 'pothole'):
                print("pothole")
                for obj in db2[j["pincode"]].find({"authUserName" : j['authUserName']}):
                    #result.append(obj)
                    result[0] = obj
            r = result[0]
            print(r)
            j["photoUrl"] = r["photoUrl"]
            j["emailId"] = r["emailId"]
            j["AJabberId"] = r["AJabberId"]
            j["phoneNo"] = r["phoneNo"]
            j["tokenId"] = r["tokenId"]
            #j["acceptDate"] = r["acceptDate"]
            print(j["acceptDate"])
            print(j["priority"])
            a = j["acceptDate"]
            c = a.split('-')
            form = m[int(c[1])]+(' ')+c[0]+(' ')+c[2]
            datetime_object = datetime.strptime(form, '%b %d %Y')
            if(j["priority"] == 'Low'):
                final = datetime_object + timedelta(days=2)
            elif(j["priority"] == 'Medium'):
                final = datetime_object + timedelta(days=4)
            elif(j["priority"] == 'High'):
                final = datetime_object + timedelta(days=6)
            fd = final.day
            fm = final.month
            fy = final.year
            if(len(str(fd)) == 1):
                fd = '0'+str(fd)
            else:
                fd = str(fd)
            if(len(str(fm)) == 1):
                fm = '0'+str(fm)
            else:
                fm = str(fm)
            fy = str(fy)
            proposedDate = fd+'-'+fm+'-'+fy
            print(proposedDate)
            j["proposedDate"] = proposedDate

            db.accept.insert(j)
            
            rm = {"complaintTitle" : j["complaintTitle"]}
            db.rejects.remove(rm)
            j["msg"] = "Job has been Assigned"
            del j['_id']
            url2 = 'https://fcm.googleapis.com/fcm/send'
            headers = {'Authorization': 'key=AIzaSyADUN07iVMT2C0zKp1GC9sUkEsSdUjFyLQ', 'Content-Type': 'application/json'}
            data2 = {
                    "to" : j['deviceId'],
                    "collapse_key" : "type_a",
                    "notification" : {
                                    "body" : "Your complaint has been accepted by Authority",
                                    "title": "Spoto",
                                    "click_action":"android.intent.action.ALL_APPS"
                                    },
                    "data" : {
                            "k" : "ok"
                            
                            }
                    }
            res = requests.request("POST", url2, json=data2, headers=headers)
            print(res.text)
            rjson = json.dumps(j)
        else:
            j["msg"] = "Job has been already assigned"
            rjson = json.dumps(j) 
        return rjson
    else:
        return "Post Your Request"

@app.route('/rejects',methods = ['POST', 'GET'])
def rejects():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        db.rejectsByAuthority.insert(j)
        j["msg"] = "Job has been rejected"
        if("_id" in j):
            del j["_id"]
        rjson = json.dumps(j)
        return rjson
    else:
        return "Post Your Request"
if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8011, threaded=True)


