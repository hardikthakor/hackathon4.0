'use strict';

var request = require('request');
var mongoose = require("mongoose");
var express = require('express');
var app = express();
var bodyParser = require('body-parser');



app.use(express.json()); 


app.get('/api/', function (req, res) {  
	
	   console.log("Get Called ...");
	  
	  res.send("Welcome To Rockstar Research Lab");  
	
	});

app.post('/api/', function (req, res) {  
	var reply;
	
	console.log(req.body);

var myJSONObject = req.body


console.log("Check for Duplicate files.....");
	mongoose.Promise = global.Promise;
	mongoose.connect("mongodb://52.230.17.234:27017/replica");
	
	//var query = {$and :[{ "type": myJSONObject.type},$or:[{ "longitude": myJSONObject.longitude},{"latitude":myJSONObject.latitude}]]};
	var query = {
      $and: [
          { $or: [{ "longitude": myJSONObject.longitude}, {"latitude":myJSONObject.latitude}] },
          { "type": myJSONObject.type} 
      ]
  };
	var userSchema = new mongoose.Schema({
		longitude:String,
		latitude :String,
		type : String,
		userId:String
	});
	var userModel = mongoose.model("backups",userSchema);

	userModel.find(query,function(err,userObj){
		if(err){
			res.send(error);
			console.log(error);
			callback(null,err);
		}
		else{
			console.log("Else Part......................................................");
			//if { "longitude": myJSONObject.longitude},{"latitude":myJSONObject.latitude}
			
			if(userObj.length == 0){
				
				console.log("NUll Printed");
				var result = {"imgUrl" : myJSONObject.imageUrl ,
"payLoad" : "success"};
				  console.log(result);
				  
				  res.send(result);
			
			}
			else{
				console.log("Duplicate");
				var result = {"payLoad" : "duplicate"}
				console.log(result);
				
				res.send(result);
			}
			
			
			
		}
	})


   delete mongoose.connection.models['backups'];

});

var server = app.listen(8549, function () {

 var host = server.address().address
  var port = server.address().port
  console.log("Example app listening at http://%s:%s", host, port)
})