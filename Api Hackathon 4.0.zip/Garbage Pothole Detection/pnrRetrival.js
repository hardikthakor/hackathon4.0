
var express = require('express');
var app = express();
var bodyParser = require('body-parser');
var mongoose = require("mongoose");

//app.use(bodyParser.json({type : "application/json"}));



app.get('/api/', function (req, res) {  
  var reply;
  //console.log("Get Called....");
  mongoose.connect("mongodb://52.230.17.234/newsFeeds");
  //console.log(req.body);
  var Schema = mongoose.Schema;
  
  var userSchema = new Schema({
 
    
      "userId":String

  }); 
  console.log('Function executed!');

  var userModel;
  if (mongoose.models.userModel) {
    userModel = mongoose.model("accept");
  }
  else {
     userModel = mongoose.model("accept",userSchema);
  }
 
  userModel.find({},{ _id : 0 },function(err,userObj){

    if(err){
      context.done();
      console.log(err);
      reply = err;
    }
    
    else{
     // console.log("Found :",userObj);
      reply = userObj;
      res.send(reply);
      
      
      
      delete mongoose.connection.models['accept'];
      
    }
  });

  
  //res.send(reply);

});

var server = app.listen(9196, function () {

 var host = server.address().address
  var port = server.address().port
  console.log("Example app listening at http://%s:%s", host, port)
})
