from flask import Flask, request, jsonify, render_template
import requests
import json
import yaml
app = Flask(__name__)



@app.route('/severity',methods = ['POST', 'GET'])
def severity():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        url1 = "https://southcentralus.api.cognitive.microsoft.com/customvision/v1.1/Prediction/71445b49-d744-4a7f-8a29-58c262195435/url?iterationId=2d15b0b9-1069-42ef-a421-cf6de2a718a9"
        imgurl = j["imageUrl"]
    
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain' , 'Prediction-Key' : 'b439bb19650f48128a7bc9d8dbc63e0f'}
        a = requests.post(url = url1, data = json.dumps({"Url" : imgurl}),headers = headers)
        s = yaml.load(a.text)
        r1 = s['Predictions'][0]['Tag']
        if(r1 == 'low'):
            severity = 'Low'
        elif(r1 == 'medium'):
            severity = 'Medium'
        elif(r1 == 'high'):
            severity = 'High'

        
        return jsonify({"payLoad" : severity,"imageUrl" : imgurl})
       
    else:
        return "get"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8555)
