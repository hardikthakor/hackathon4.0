from flask import Flask, request, jsonify, render_template
import requests
import json
import yaml
app = Flask(__name__)



@app.route('/severity',methods = ['POST', 'GET'])
def severity():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        url1 = "https://southcentralus.api.cognitive.microsoft.com/customvision/v1.1/Prediction/e333846d-f44b-4571-b9e6-bbcb1fada2ad/url?iterationId=40ba4910-cbd0-496c-ace9-bdc1fe7e147e"
        imgurl = j["imageUrl"]
    
        headers = {'Content-type': 'application/json', 'Accept': 'text/plain' , 'Prediction-Key' : 'b439bb19650f48128a7bc9d8dbc63e0f'}
        a = requests.post(url = url1, data = json.dumps({"Url" : imgurl}),headers = headers)
        s = yaml.load(a.text)
        r1 = s['Predictions'][0]['Tag']
        if(r1 == 'low'):
            severity = 'Low'
        elif(r1 == 'medium'):
            severity = 'Medium'
        elif(r1 == 'high'):
            severity = 'High'

        return jsonify({"payLoad" : severity,"imageUrl" : imgurl})
       
    else:
        return "get"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8666)
