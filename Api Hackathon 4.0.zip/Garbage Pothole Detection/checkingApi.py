from flask import Flask, request, jsonify, render_template
import pymongo
from pymongo import MongoClient
import json

app = Flask(__name__)

client = MongoClient('52.230.17.234',27017)
db = client['replica']

@app.route('/check',methods = ['POST', 'GET'])
def check():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        count = count = db.rejects.find({"complaintTitle" : j['complaintTitle']}).count()
        if (count != 0):
            j["msg"] = "ok"
        else:
            j["msg"] = "notOk"
        if("_id" in j):
            del j['_id']
        rjson = json.dumps(j) 
        return rjson
    else:
        return "get"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8123, threaded=True)


