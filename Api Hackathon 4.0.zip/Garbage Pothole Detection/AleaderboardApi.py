from flask import Flask, request, jsonify, render_template
import pymongo
from pymongo import MongoClient


client = MongoClient('52.230.17.234',27017)
db = client['authorityDetails']
app = Flask(__name__)



@app.route('/AleaderBD',methods = ['POST', 'GET'])
def AleaderBD():
    print('okkkkkk')
    if request.method == 'POST':
        j = request.json
        for obj in db.authorityPwd.find({"authUserName": j["authUserName"],"pincode":j["pincode"]}):
            if("_id" in obj):
                del obj["_id"]
            a = obj
        if j['priority'] == "High":
            a["points"] = int(a["points"]) + 300
        elif j['priority'] == "Medium":
            a["points"] = int(a["points"]) + 200
        else:
            a["points"] = int(a["points"]) + 100
        if("_id" in a):
            del a["_id"]
        a["complaintsCount"] = str(int(a["complaintsCount"]) + 1)
        db.authorityPwd.remove({"authUserName": j["authUserName"],"pincode":j["pincode"]})
        db.authorityPwd.insert(a)
        
        return "ok"
    else:
        return "get"
if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8886, threaded=True)


