var express = require('express');
var app = express();
var redis = require('redis');
//var redis = new Redis();
var client = redis.createClient(6379, '52.230.17.234');
var async = require('async');
const asyncMap = require('async-map')
app.use(express.json());
app.post('/api/', function (req, res){  
    console.log("Function Executed");
    
    var garbage=[];
    var pothole=[];

client.keys('*', function (err, keys) {
    if (err) return console.log(err);
    if(keys){
        async.map(keys, function(key, cb) {
           client.get(key, function (error, value) {
                if (error) return cb(error);
                var job = {};
                job=JSON.parse(value);
                if(job.type == "garbage")
                {
                    garbage.push(job);
                }
                if(job.type == "pothole")
                {
                    pothole.push(job);
                }
                //job=value;
                cb(null, job);
            }); 
        }, function (error, results) {
           if (error) return console.log(error);
           var returnJson=[];
                returnJson["all"]=results;
                returnJson["garbage"]=garbage;
                returnJson["pothole"]=pothole;
            res.send(results);
                
  }
);
} 
});


});

var server = app.listen(8090, function () {

  var port = server.address().port
  console.log("Example app listening at http://%s:%s", port)
})
















/****function done1(){
                for(var item=0;item<results.length;item++){
            
                    // console.log(item);
                 if(results[item].type == "garbage")
                 {
                     garbage.push(results[item]);
                 }
                if(results[item].type == "pothole")
                 {
                     pothole.push(results[item]);
                 }
                 
                 };
                 returnJson["all"]=results;
                returnJson["garbage"]=garbage;
                returnJson["pothole"]=pothole;
                console.log(returnJson);
                return returnJson;
            }
            
            function done2(){
                res.send(returnJson);
            }
            done1();done2(); 
*/

/*function done1(){
    var ret;
    setTimeout(function(){
        for(var item=0;item<results.length;item++){

            // console.log(item);
         if(results[item].type == "garbage")
         {
             garbage.push(results[item]);
         }
        if(results[item].type == "pothole")
         {
             pothole.push(results[item]);
         }
         
         };
         returnJson["all"]=results;
        returnJson["garbage"]=garbage;
        returnJson["pothole"]=pothole;
        console.log(returnJson);
        ret=returnJson;
    });
    while(ret === undefined) {
        require('deasync').runLoopOnce();
    }
    
    return ret;
}
var abc = done1();
res.send(abc);*/











