var fb = require('fb');
var fs = require('fs');
var exp = require('express');
var app = exp();
var Twitter = require('node-twitter');
var request = require('request');
//facebook token id
fb.setAccessToken('EAACEdEose0cBAFqA0StH4yZCgrZCZC0GzEHCEWrCZCwFCa0PfkCjxb71OM71WYa7sC9Qt83kfxAvFoFFrSBB1wArHdPvpNtYPLnC9GbpGGI4ZCqpA5g9eXgReHRfj1BlhX8JKNDSwJkU9CiyY7QuXw64rj80t6gnVpyZCOSx9vLVV7guRKPiGlWaFZBbfAXDOUZD');

//twitter token id
var twitterRestClient = new Twitter.RestClient(
    'qpVLweTFnVfEp9j1BsY2koeZI',
    'svwWE0ZJjusDmVGLageGlFYPwkQHXQOFdkHwirhnZQmveisGfX',
    '955034718235316224-10m2sbjolt6D8Edj7UFIZyxduyivq1m',
    'vAp5iMiwMCRAsbpQuMdcioVE25zvc9w9R0OZQJEcqdq4D'
);


 
app.post('/upload', function (req, res) {

//var path_azure = req.body.imageUrl;

//var desc = req.body.description;

var path_azure = "https://citizenserviceapp2.s3.amazonaws.com/thakorchetna70%40gmail.com/pothole-2018-02-15%2012%3A05%3A16.923132.jpg";

var desc = "ynwa";

var download = function(uri, filename, callback){
 request.head(uri, function(err, res, body){
   console.log('content-type:', res.headers['content-type']);
   console.log('content-length:', res.headers['content-length']);

   request(uri).pipe(fs.createWriteStream(filename)).on('close', callback);
 });
};

download(path_azure, 'rockstars.jpg', function(){
 console.log('done');
});




    //image path
//var path = req.body.imageUrl;
var path = "https://www.w3schools.com/w3css/img_fjords.jpg";
    fb.api('me/photos', 'post', { source : fs.createReadStream(path), caption: desc}, function (res) {
    if(!res || res.error) {
      console.log(!res ? 'error occurred' : res.error);
      return;
    }
    console.log('Post Id: ' + res.post_id);
   });

   twitterRestClient.statusesUpdateWithMedia(
    {
        'status': desc,
        'media[]': path
    },
    function(error, result) {
        if (error)
        {
            console.log('Error: ' + (error.code ? error.code + ' ' + error.message : error.message));
        }
 
        if (result)
        {
            console.log(result);
        }
    }
);
console.log("Api Started .....");
  res.send('Posted Successfully');
});


var server = app.listen(8076, function () {

var host = server.address().address
 var port = server.address().port
 console.log("Example app listening at http://%s:%s", host, port)
})
