var express = require('express');
var app = express();
var mongoose = require("mongoose");
app.use(express.json());


app.get('/api/', function (req, res) {  
  
    console.log("Get Called ...");
   
   res.send("Welcome To Rockstar Research Lab");  
 
 });


app.get('/all', function (req, res){
  console.log("All Called....");
  mongoose.connect("mongodb://52.230.17.234/replica");
  console.log(req.body);
  var Schema = mongoose.Schema;
  
  var userSchema = new Schema({
    image_id:String,
    name:String,
    email:String,
    mobile:String
  });


  var userModel;
  if (mongoose.models.userModel) {
    userModel = mongoose.model("abcs");
  }
  else {
     userModel = mongoose.model("abcs",userSchema);
  }
 
  userModel.find(function(err,userObj){

    if(err){
      context.done();
      console.log(err);
      res.send(err);
    }
    
    else{
      console.log("Found :",userObj);      
      res.send(userObj);
      delete mongoose.connection.models['abcs'];
      
    }
  });

});





app.get('/garbage', function (req, res){ 
    console.log("Garbage Called...");
    mongoose.connect("mongodb://52.230.17.234/replica");
  console.log(req.body);
  var Schema = mongoose.Schema;
  
  var userSchema = new Schema({
    image_id:String,
    name:String,
    email:String,
    mobile:String
  });


  var userModel;
  if (mongoose.models.userModel) {
    userModel = mongoose.model("abcs");
  }
  else {
     userModel = mongoose.model("abcs",userSchema);
  }
 
  userModel.find({"type":"garbage"},function(err,userObj){

    if(err){
      context.done();
      console.log(err);
      res.send(err);
    }
    
    else{
      console.log("Found :",userObj);      
      res.send(userObj);
      delete mongoose.connection.models['abcs'];
      
    }
  });

});





app.get('/pothole', function (req, res){
    console.log("Pothole Called....");
    mongoose.connect("mongodb://52.230.17.234/replica");
  console.log(req.body);
  var Schema = mongoose.Schema;
  
  var userSchema = new Schema({
    image_id:String,
    name:String,
    email:String,
    mobile:String
  });


  var userModel;
  if (mongoose.models.userModel) {
    userModel = mongoose.model("abcs");
  }
  else {
     userModel = mongoose.model("abcs",userSchema);
  }
 
  userModel.find({"type":"pothole"},function(err,userObj){

    if(err){
      context.done();
      console.log(err);
      res.send(err);
    }
    
    else{
      console.log("Found :",userObj);      
      res.send(userObj);
      delete mongoose.connection.models['abcs'];
      
    }
  });

});

var server = app.listen(8413, function () {

  var port = server.address().port
  console.log("Example app listening at http://%s:%s", port)
})











