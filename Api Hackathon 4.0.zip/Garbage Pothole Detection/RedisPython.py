import redis
import json
from flask import Flask, request, jsonify, render_template
import requests
from requests.auth import HTTPBasicAuth
import urllib
import yaml



app = Flask(__name__)

@app.route('/all',methods = ['POST', 'GET'])
def all():
    if request.method == 'GET':
       

        print ("Hit")
        r = redis.StrictRedis(host='52.230.17.234', port=6379)
        key=r.keys("*")
        print(key)
        f= []
        final = []
        g = []
        for i in key:
            tempKey = i.decode("utf-8")
            f.append(r.get(tempKey).decode("utf-8"))
#            print('hello bro')
        for iter in f:
            print(iter)
            jsonData = yaml.load(iter)
            final.append(jsonData)
            print('hello brother')
        g  = final
        print(g)
        rjson = json.dumps(g)
        return rjson
    else:
        return "Get"

@app.route('/garbage',methods = ['POST', 'GET'])
def garbage():
    if request.method == 'GET':
    

        print ("Hit")
        r = redis.StrictRedis(host='52.230.17.234', port=6379)
        key=r.keys("*")
        
        f= []
        garbage = []
        for i in key:
            tempKey = i.decode("utf-8")
            f.append(r.get(tempKey).decode("utf-8"))
        for iter in f:
            jsonData = yaml.load(iter)
            if jsonData['type'] == "garbage":
                garbage.append(jsonData)
            
        g =  garbage
        
        rjson = json.dumps(g)
        return rjson
    else:
        return "GET"


@app.route('/pothole',methods = ['POST', 'GET'])
def pothole():
    if request.method == 'GET':
    
        print ("Hit")
        r = redis.StrictRedis(host='52.230.17.234', port=6379)
        key=r.keys("*")
        
        f= []
        pothole = []
        for i in key:
            tempKey = i.decode("utf-8")
            f.append(r.get(tempKey).decode("utf-8"))
        for iter in f:
            jsonData = yaml.load(iter)
            if jsonData['type'] == "pothole":
                pothole.append(jsonData)
            

        g = pothole
        rjson = json.dumps(g)
        return rjson
    else:
        return "GET"


if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8413, threaded=True)
