from flask import Flask, request, jsonify, render_template
import pymongo
from pymongo import MongoClient
import json

app = Flask(__name__)

client = MongoClient('52.230.17.234',27017)
db = client['userDetails']
result = []

@app.route('/userdata',methods = ['POST', 'GET'])
def userdata():
    print('okkkkkk')
    if request.method == 'GET':
        j = request.json
        count = db.data.find().count()
        if(count != 0):
            for obj in db.data.find().sort("points", pymongo.DESCENDING):
                if("_id" in obj):
                    del obj["_id"]
                result.append(obj)
               
            rjson = json.dumps(result)
            result.clear()
        else:
            rjson = json.dumps({"flag": "null"})            
        return rjson
    else:
        return "Post Your Request"

if __name__ == '__main__':
    app.run(debug = True, host='0.0.0.0', port=8127, threaded=True)
